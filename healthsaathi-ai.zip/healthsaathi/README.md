# HealthSaathi AI — Personal Health Copilot (hackathon build)

Next.js 14 + TypeScript + Tailwind + Supabase-ready. English/Tamil. **Runs in labelled DEMO mode with no keys.**

> Not medical advice. All doctors, donors, phone numbers and reports are fictional DEMO data.

## Quick start
```bash
npm install
cp .env.example .env.local    # optional: demo mode works without it
npm run dev                   # http://localhost:3000
npm run typecheck && npm run lint && npm test && npm run build
```

## What works now vs. what is scaffolded
| Module | Status |
|---|---|
| Landing, dashboard, timeline, Tamil/English switch | Working (demo data in browser localStorage) |
| Records upload → validation (type, size, file signature) → OCR pipeline → review table → approve | Working with **demo OCR** (fixed sample text, clearly labelled). Real OCR = implement `OcrProvider` in `src/lib/ocr.ts` |
| Lab flagging | Only from the lab's own printed reference range; never invented |
| Doctor directory (33 specialties), filters, appointment *requests* | Working with SAMPLE/DEMO doctors; requests are not confirmations |
| Medicine schedules, today's doses, taken/skipped, browser notifications | Working (in-tab only while the page is open) |
| Wellness planner | Working |
| Emergency SOS | `tel:112` link, contacts, confirmation, timestamped event. Alert is **prepared as an SMS link, not auto-sent** |
| Blood donation | Registration, requests, consent-only matching, duplicate prevention, in-app notices |
| AI chat | Server route with emergency pre-check, rate limit, zod validation. Live answers need `AI_*` env vars, else labelled DEMO |
| Supabase schema + RLS + private bucket | SQL provided in `supabase/migrations/0001_schema.sql` (**not yet executed by me**) |
| Auth UI, provider/admin dashboards, home-visit UI, PDF text extraction, AI record summaries, server-side persistence | **Not built yet** (see limitations) |

## Architecture
```mermaid
flowchart LR
  P[Patient UI] --> A[Supabase Auth]
  A --> B[Next.js API routes]
  B --> O[OCR / document parsing]
  O --> S[Structured medical data]
  S --> AI[AI explanation]
  S --> DB[(PostgreSQL + RLS)]
  AI --> DB
  DB --> D[Dashboard and notifications]
  B --> DR[Doctor directory]
  B --> E[Emergency assistance]
  B --> BD[Blood donation matching]
  B --> R[Reminder scheduler]
  DR --> DB
  E --> DB
  BD --> DB
  R --> DB
  R --> D
```

## Document pipeline
validate type/size → check real file signature → text/OCR → parse candidates → user review → save approved rows → AI explanation (labelled, separate from facts).

## FHIR-style mapping (inspired, not conformant)
medical_documents→DocumentReference · observations→Observation · extracted_medical_records→DiagnosticReport · conditions→Condition · medications→MedicationRequest/Statement · appointments→Appointment · doctors→Practitioner · hospitals→Organization · profiles→Patient. ABHA is a mock field only; no ABDM integration is claimed.

## Security notes
RLS owner-only on all patient tables; admins have **no** policy on medical data; roles writable only with the service role; private storage bucket with per-user folders; security headers; rate limits; no document text in logs. The in-memory rate limiter is per-instance: use Redis/Upstash in production. Obtain legal review for India's DPDP Act 2023 before real use.

## Reminders in production
Browser notifications work only while the tab is open. For real reminders add a Supabase scheduled function (pg_cron) or Vercel Cron that reads `medication_schedules` and inserts into `notifications`, plus an authorised push/SMS/email provider.

## Deploy
1. Create a GitHub repo, then `git init && git add . && git commit -m "Initial commit" && git branch -M main && git remote add origin <your-repo-url> && git push -u origin main`.
2. Supabase: create a project, run `supabase/migrations/0001_schema.sql`, then optionally `supabase/seed.sql`.
3. Vercel: import the repo, set the variables from `.env.example`, deploy. Keep `SUPABASE_SERVICE_ROLE_KEY` server-only.

## Hackathon pitch outline
Problem (scattered records, language barrier) → live demo: upload, review, flag → Tamil switch → SOS + blood match → safety design (no diagnosis, consent-only alerts) → roadmap.

## Known limitations
Not yet installed, type-checked, linted or built by the author. Auth screens, provider/admin dashboards, PDF text extraction, real OCR, persisted server data and Playwright e2e tests are still to do.
