import { describe, expect, it } from "vitest";
import { parseMedicalText } from "@/lib/ocr";

describe("OCR text parsing", () => {
  it("flags values using the lab's own reference range only", () => {
    const [hb, glu, chol] = parseMedicalText("Haemoglobin 11.2 g/dL 13.0 - 17.0\nFasting Glucose 112 mg/dL 70 - 100\nTotal Cholesterol 182 mg/dL 0 - 200");
    expect(hb.flag).toBe("low"); expect(glu.flag).toBe("high"); expect(chol.flag).toBe("within");
  });
  it("does not invent units or ranges that are missing", () => {
    expect(parseMedicalText("Some random line 12")).toHaveLength(0);
    expect(parseMedicalText("Hb 11 13 - 17")[0].needsReview).toBe(true);
  });
  it("marks medicines for review", () => {
    const m = parseMedicalText("Tab. Metformin 500 mg twice daily")[0];
    expect(m.kind).toBe("medicine"); expect(m.needsReview).toBe(true);
  });
});
