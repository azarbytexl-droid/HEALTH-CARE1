import { describe, expect, it } from "vitest";
import { adherenceSummary, dosesForDate, isValidTime, type Schedule } from "@/lib/schedule";

const s: Schedule = { id: "s1", medicine: "Demo", dosage: "1 tablet", times: ["20:00", "08:00", "08:00", "99:99"], startDate: "2026-06-01", endDate: "2026-06-03", reminders: true };

describe("schedule", () => {
  it("validates HH:MM", () => { expect(isValidTime("08:00")).toBe(true); expect(isValidTime("8:00")).toBe(false); expect(isValidTime("24:00")).toBe(false); });
  it("dedupes, sorts and drops invalid times", () => { expect(dosesForDate(s, "2026-06-02").map((d) => d.time)).toEqual(["08:00", "20:00"]); });
  it("respects start and end dates", () => { expect(dosesForDate(s, "2026-05-31")).toHaveLength(0); expect(dosesForDate(s, "2026-06-04")).toHaveLength(0); expect(dosesForDate(s, "2026-06-03")).toHaveLength(2); });
  it("summarises adherence", () => {
    const d = dosesForDate(s, "2026-06-02");
    expect(adherenceSummary(d, { [d[0].key]: "taken", [d[1].key]: "skipped" })).toEqual({ total: 2, taken: 1, skipped: 1, notRecorded: 0 });
  });
});
