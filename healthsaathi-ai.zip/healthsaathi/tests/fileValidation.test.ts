import { describe, expect, it } from "vitest";
import { sniffType, validateUpload } from "@/lib/fileValidation";

describe("upload validation", () => {
  it("accepts a small PDF", () => expect(validateUpload({ name: "a.pdf", size: 1000, type: "application/pdf" }, 5000).ok).toBe(true));
  it("rejects oversize, empty, wrong type and path names", () => {
    expect(validateUpload({ name: "a.pdf", size: 9000, type: "application/pdf" }, 5000).ok).toBe(false);
    expect(validateUpload({ name: "a.pdf", size: 0, type: "application/pdf" }, 5000).ok).toBe(false);
    expect(validateUpload({ name: "a.exe", size: 10, type: "application/x-msdownload" }, 5000).ok).toBe(false);
    expect(validateUpload({ name: "../a.pdf", size: 10, type: "application/pdf" }, 5000).ok).toBe(false);
  });
  it("sniffs real signatures", () => {
    expect(sniffType(new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d]))).toBe("application/pdf");
    expect(sniffType(new Uint8Array([0x89, 0x50, 0x4e, 0x47]))).toBe("image/png");
    expect(sniffType(new Uint8Array([0xff, 0xd8, 0xff, 0xe0]))).toBe("image/jpeg");
    expect(sniffType(new Uint8Array([1, 2, 3, 4]))).toBeNull();
  });
});
