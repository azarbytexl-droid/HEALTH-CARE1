import { describe, expect, it } from "vitest";
import { isCompatible, isDuplicateRequest, matchDonors, type BloodRequest, type Donor } from "@/lib/blood";

const donor = (o: Partial<Donor>): Donor => ({ id: "x", displayName: "D", group: "A+", city: "Chennai", available: true, consentToMatch: true, verified: false, isDemo: true, ...o });
const req: BloodRequest = { id: "r", group: "A+", city: "Chennai", hospital: "H", urgency: "urgent", status: "open", requiredBy: "2026-01-01", verified: false };
const now = new Date("2026-06-01");

describe("blood matching", () => {
  it("strict mode: A+ recipient accepts A+ and A-, not O+ or B+", () => {
    expect(isCompatible("A+", "A+")).toBe(true);
    expect(isCompatible("A-", "A+")).toBe(true);
    expect(isCompatible("O+", "A+")).toBe(false);
    expect(isCompatible("B+", "A+")).toBe(false);
  });
  it("Rh+ donor never matches Rh- recipient", () => {
    expect(isCompatible("A+", "A-", "strict")).toBe(false);
    expect(isCompatible("O+", "A-", "red_cell_full")).toBe(false);
  });
  it("full mode: O- is universal red-cell donor", () => {
    (["O+","O-","A+","A-","B+","B-","AB+","AB-"] as const).forEach((g) => expect(isCompatible("O-", g, "red_cell_full")).toBe(true));
  });
  it("only consenting, available, same-city donors are matched", () => {
    const list = [donor({ id: "1" }), donor({ id: "2", consentToMatch: false }), donor({ id: "3", available: false }), donor({ id: "4", city: "Salem" }), donor({ id: "5", group: "A-" })];
    expect(matchDonors(req, list, now).map((d) => d.id)).toEqual(["1", "5"]);
  });
  it("excludes donors who donated within 90 days", () => {
    expect(matchDonors(req, [donor({ lastDonation: "2026-05-01" })], now)).toHaveLength(0);
    expect(matchDonors(req, [donor({ lastDonation: "2026-01-01" })], now)).toHaveLength(1);
  });
  it("closed requests match nobody", () => {
    expect(matchDonors({ ...req, status: "cancelled" }, [donor({})], now)).toHaveLength(0);
  });
  it("detects duplicate open requests", () => {
    expect(isDuplicateRequest([req], { group: "A+", hospital: " h ", city: "chennai" })).toBe(true);
    expect(isDuplicateRequest([{ ...req, status: "fulfilled" }], { group: "A+", hospital: "H", city: "Chennai" })).toBe(false);
  });
});
