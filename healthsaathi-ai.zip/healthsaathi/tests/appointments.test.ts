import { describe, expect, it } from "vitest";
import { canActorTransition, canTransition } from "@/lib/appointments";

describe("appointment transitions", () => {
  it("allows the normal flow", () => { expect(canTransition("requested", "confirmed")).toBe(true); expect(canTransition("confirmed", "completed")).toBe(true); });
  it("blocks terminal and skipped states", () => { expect(canTransition("cancelled", "confirmed")).toBe(false); expect(canTransition("requested", "completed")).toBe(false); });
  it("patients cannot confirm", () => { expect(canActorTransition("patient", "requested", "confirmed")).toBe(false); expect(canActorTransition("patient", "requested", "cancelled")).toBe(true); expect(canActorTransition("provider", "requested", "confirmed")).toBe(true); });
});
