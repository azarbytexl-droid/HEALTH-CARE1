import { SYSTEM_PROMPT } from "./safety";

export type AiResult = { mode: "live" | "demo" | "error"; text: string };

export const aiConfigured = () => Boolean(process.env.AI_API_KEY && process.env.AI_BASE_URL && process.env.AI_MODEL);

export async function askAi(messages: { role: "user" | "assistant"; content: string }[]): Promise<AiResult> {
  if (!aiConfigured()) {
    return { mode: "demo", text: "DEMO MODE: no AI key is configured, so this is not a live AI answer. Set AI_API_KEY, AI_BASE_URL and AI_MODEL to enable live responses." };
  }
  try {
    const res = await fetch(`${process.env.AI_BASE_URL}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.AI_API_KEY}` },
      body: JSON.stringify({
        model: process.env.AI_MODEL,
        temperature: 0.2,
        messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages.slice(-12)]
      }),
      signal: AbortSignal.timeout(30000)
    });
    if (!res.ok) return { mode: "error", text: "The AI service is unavailable right now. Please try again later." };
    const json = await res.json();
    const text = json?.choices?.[0]?.message?.content;
    if (typeof text !== "string" || !text) return { mode: "error", text: "The AI service returned an empty answer." };
    return { mode: "live", text };
  } catch {
    return { mode: "error", text: "The AI service could not be reached." };
  }
}
