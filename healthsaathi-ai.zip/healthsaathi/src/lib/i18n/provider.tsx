"use client";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { dictionaries, type Key, type Lang } from "./dictionary";

type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: (k: Key) => string };
const I18n = createContext<Ctx>({ lang: "en", setLang: () => {}, t: (k) => k });

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");
  useEffect(() => {
    const s = localStorage.getItem("hs-lang");
    if (s === "en" || s === "ta") setLangState(s);
  }, []);
  useEffect(() => { document.documentElement.lang = lang; }, [lang]);
  const setLang = (l: Lang) => { setLangState(l); try { localStorage.setItem("hs-lang", l); } catch {} };
  const t = (k: Key) => dictionaries[lang][k] ?? dictionaries.en[k] ?? k;
  return <I18n.Provider value={{ lang, setLang, t }}>{children}</I18n.Provider>;
}

export const useI18n = () => useContext(I18n);
