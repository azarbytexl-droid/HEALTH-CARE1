export type Schedule = {
  id: string;
  medicine: string;
  dosage: string; // exactly as prescribed, never computed by AI
  times: string[]; // "HH:MM" confirmed by the user from the prescription
  startDate: string; // YYYY-MM-DD
  endDate?: string;
  reminders: boolean;
};
export type DoseStatus = "taken" | "skipped" | "not_recorded";
export type Dose = { scheduleId: string; medicine: string; dosage: string; date: string; time: string; key: string };

export const isValidTime = (t: string) => /^([01]\d|2[0-3]):[0-5]\d$/.test(t);

/** Returns doses for a date. Never invents times: only the user-confirmed times are used. */
export function dosesForDate(s: Schedule, date: string): Dose[] {
  if (date < s.startDate) return [];
  if (s.endDate && date > s.endDate) return [];
  return [...new Set(s.times.filter(isValidTime))]
    .sort()
    .map((time) => ({ scheduleId: s.id, medicine: s.medicine, dosage: s.dosage, date, time, key: `${s.id}|${date}|${time}` }));
}

export function adherenceSummary(doses: Dose[], log: Record<string, DoseStatus>) {
  const taken = doses.filter((d) => log[d.key] === "taken").length;
  const skipped = doses.filter((d) => log[d.key] === "skipped").length;
  return { total: doses.length, taken, skipped, notRecorded: doses.length - taken - skipped };
}

export const todayISO = (d = new Date()) => {
  const z = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
};
