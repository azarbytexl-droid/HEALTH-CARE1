export type Extracted = {
  kind: "observation" | "medicine";
  name: string;
  value?: string;
  unit?: string;
  refLow?: number;
  refHigh?: number;
  flag?: "low" | "high" | "within";
  raw: string;
  confidence: number; // 0..1, heuristic for parsed lines; provider confidence when available
  needsReview: boolean;
};

const LAB = /^([A-Za-z][A-Za-z0-9 /()%-]{1,40}?)\s+(\d+(?:\.\d+)?)\s*([A-Za-z/%µ^0-9.]{0,12})\s+(\d+(?:\.\d+)?)\s*[-–]\s*(\d+(?:\.\d+)?)\s*$/;
const MED = /^(?:tab|cap|syp|inj)\.?\s+([A-Za-z][A-Za-z0-9 -]{1,30}?)\s+(\d+(?:\.\d+)?\s?(?:mg|mcg|g|ml|iu))\b(.*)$/i;

/** Parses text lines. Never fills in values that are not present in the text. */
export function parseMedicalText(text: string): Extracted[] {
  const out: Extracted[] = [];
  for (const line of text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean)) {
    const lab = LAB.exec(line);
    if (lab) {
      const value = Number(lab[2]), refLow = Number(lab[4]), refHigh = Number(lab[5]);
      const flag = refLow > refHigh ? undefined : value < refLow ? "low" : value > refHigh ? "high" : "within";
      out.push({
        kind: "observation", name: lab[1].trim(), value: lab[2], unit: lab[3] || undefined, refLow, refHigh, flag,
        raw: line, confidence: lab[3] ? 0.85 : 0.6, needsReview: !lab[3] || flag === undefined
      });
      continue;
    }
    const med = MED.exec(line);
    if (med) {
      out.push({ kind: "medicine", name: med[1].trim(), value: med[2], raw: line, confidence: 0.7, needsReview: true });
    }
  }
  return out;
}

export interface OcrProvider {
  readonly id: string;
  readonly isDemo: boolean;
  extract(file: { bytes: Uint8Array; type: string; name: string }): Promise<{ text: string; confidence?: number }>;
}

export const DEMO_SAMPLE_TEXT = `Haemoglobin 11.2 g/dL 13.0 - 17.0
Fasting Glucose 112 mg/dL 70 - 100
Total Cholesterol 182 mg/dL 0 - 200
Tab. Metformin 500 mg twice daily after food`;

/** Demo provider: returns fixed fictional sample text. Real OCR must be plugged in by implementing OcrProvider. */
export const demoOcr: OcrProvider = {
  id: "demo",
  isDemo: true,
  async extract() { return { text: DEMO_SAMPLE_TEXT, confidence: undefined }; }
};

export function getOcrProvider(): OcrProvider {
  // Add real providers here (e.g. a cloud OCR API) keyed by process.env.OCR_PROVIDER.
  return demoOcr;
}
