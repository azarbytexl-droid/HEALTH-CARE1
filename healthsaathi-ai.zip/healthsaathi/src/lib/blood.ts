export const BLOOD_GROUPS = ["O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"] as const;
export type BloodGroup = (typeof BLOOD_GROUPS)[number];

export type Donor = {
  id: string;
  displayName: string;
  group: BloodGroup;
  city: string;
  locality?: string;
  available: boolean;
  consentToMatch: boolean;
  lastDonation?: string; // ISO date, voluntary
  verified: boolean;
  isDemo: boolean;
};

export type BloodRequest = {
  id: string;
  group: BloodGroup;
  units?: number;
  city: string;
  hospital: string;
  urgency: "routine" | "urgent" | "critical";
  status: "open" | "fulfilled" | "cancelled" | "expired";
  requiredBy: string;
  verified: boolean;
};

export type MatchMode = "strict" | "red_cell_full";

function split(g: BloodGroup) {
  return { abo: g.slice(0, -1), rh: g.endsWith("+") ? "+" : "-" } as const;
}

/**
 * Basic demo compatibility. NOT a clinical decision: blood-bank professionals must confirm.
 * strict: same ABO group; Rh-negative donors may serve Rh-positive recipients (A+ <- A+, A-).
 * red_cell_full: standard red-cell ABO/Rh compatibility chart.
 */
export function isCompatible(donor: BloodGroup, recipient: BloodGroup, mode: MatchMode = "strict"): boolean {
  const d = split(donor), r = split(recipient);
  const rhOk = d.rh === "-" || r.rh === "+";
  if (!rhOk) return false;
  if (mode === "strict") return d.abo === r.abo;
  if (d.abo === "O") return true;
  if (d.abo === "A") return r.abo === "A" || r.abo === "AB";
  if (d.abo === "B") return r.abo === "B" || r.abo === "AB";
  return r.abo === "AB";
}

export const DONATION_INTERVAL_DAYS = 90;

export function daysBetween(a: Date, b: Date) {
  return Math.floor((b.getTime() - a.getTime()) / 86400000);
}

export function isEligibleByInterval(lastDonation: string | undefined, now: Date, minDays = DONATION_INTERVAL_DAYS) {
  if (!lastDonation) return true; // unknown: bank screening decides
  return daysBetween(new Date(lastDonation), now) >= minDays;
}

/** Only opted-in, available, same-city, interval-eligible donors are candidates. */
export function matchDonors(
  req: BloodRequest, donors: Donor[], now = new Date(), mode: MatchMode = "strict"
): Donor[] {
  if (req.status !== "open") return [];
  return donors.filter(
    (d) =>
      d.consentToMatch &&
      d.available &&
      d.city.trim().toLowerCase() === req.city.trim().toLowerCase() &&
      isCompatible(d.group, req.group, mode) &&
      isEligibleByInterval(d.lastDonation, now)
  );
}

/** Duplicate prevention: same group + hospital + city while still open. */
export function isDuplicateRequest(existing: BloodRequest[], next: Pick<BloodRequest, "group" | "hospital" | "city">) {
  const n = (s: string) => s.trim().toLowerCase();
  return existing.some(
    (e) => e.status === "open" && e.group === next.group && n(e.hospital) === n(next.hospital) && n(e.city) === n(next.city)
  );
}
