"use client";
import { useEffect, useState } from "react";

/** Demo-mode persistence in the browser. Replace with Supabase queries when connected. */
export function useLocalState<T>(key: string, initial: T) {
  const [v, setV] = useState<T>(initial);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try { const s = localStorage.getItem(key); if (s) setV(JSON.parse(s)); } catch {}
    setReady(true);
  }, [key]);
  useEffect(() => {
    if (ready) { try { localStorage.setItem(key, JSON.stringify(v)); } catch {} }
  }, [key, v, ready]);
  return [v, setV, ready] as const;
}
