export const ALLOWED_TYPES = ["application/pdf", "image/png", "image/jpeg", "image/webp"] as const;

export type FileMeta = { name: string; size: number; type: string };

export function maxBytes(mb = Number(process.env.MAX_UPLOAD_MB ?? 10)) {
  return Math.max(1, mb) * 1024 * 1024;
}

export function validateUpload(f: FileMeta, limit = maxBytes()): { ok: true } | { ok: false; error: string } {
  if (!f.size) return { ok: false, error: "File is empty." };
  if (f.size > limit) return { ok: false, error: `File is larger than ${Math.round(limit / 1048576)} MB.` };
  if (!(ALLOWED_TYPES as readonly string[]).includes(f.type)) return { ok: false, error: "Only PDF, PNG, JPEG or WebP files are allowed." };
  if (/[\\/]|\.\./.test(f.name)) return { ok: false, error: "Invalid file name." };
  return { ok: true };
}

/** Checks the real file signature so a renamed file cannot bypass the type check. */
export function sniffType(bytes: Uint8Array): string | null {
  const h = (...b: number[]) => b.every((v, i) => bytes[i] === v);
  if (h(0x25, 0x50, 0x44, 0x46)) return "application/pdf";
  if (h(0x89, 0x50, 0x4e, 0x47)) return "image/png";
  if (h(0xff, 0xd8, 0xff)) return "image/jpeg";
  if (h(0x52, 0x49, 0x46, 0x46) && bytes[8] === 0x57 && bytes[9] === 0x45) return "image/webp";
  return null;
}
