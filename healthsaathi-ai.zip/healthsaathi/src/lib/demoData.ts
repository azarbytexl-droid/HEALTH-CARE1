import type { Donor, BloodRequest } from "./blood";

export const SPECIALTIES = [
  "Cardiology", "Neurology", "Neurosurgery", "Pulmonology", "Gastroenterology", "Hepatology", "Nephrology", "Urology",
  "Endocrinology", "Dermatology", "Orthopedics", "Rheumatology", "Gynecology", "Obstetrics", "Pediatrics", "Neonatology",
  "Ophthalmology", "ENT / Otolaryngology", "Dentistry", "Oncology", "Hematology", "Psychiatry", "Psychology",
  "General / Internal Medicine", "Family Medicine", "Geriatrics", "Infectious Disease", "Physical Medicine and Rehabilitation",
  "Physiotherapy", "Nutrition and Dietetics", "Emergency Medicine", "Anesthesiology and Pain Medicine", "Palliative Care"
] as const;

export type DemoDoctor = {
  id: string; name: string; specialty: string; city: string; locality: string; hospital: string;
  languages: string[]; online: boolean; homeVisit: boolean; slots: string[]; verified: false; isDemo: true;
};

// Entirely fictional. No real people, registrations, phone numbers or claims.
export const DEMO_DOCTORS: DemoDoctor[] = [
  { id: "d1", name: "Dr. Demo Cardiologist", specialty: "Cardiology", city: "Chennai", locality: "Sample Nagar", hospital: "DEMO Heart Centre", languages: ["English", "Tamil"], online: true, homeVisit: false, slots: ["Mon 10:00", "Wed 15:30"], verified: false, isDemo: true },
  { id: "d2", name: "Dr. Demo Neurologist", specialty: "Neurology", city: "Coimbatore", locality: "Sample Colony", hospital: "DEMO Neuro Clinic", languages: ["English", "Tamil"], online: true, homeVisit: false, slots: ["Tue 11:00"], verified: false, isDemo: true },
  { id: "d3", name: "Dr. Demo Obstetrician", specialty: "Obstetrics", city: "Chennai", locality: "Example Park", hospital: "DEMO Maternity Hospital", languages: ["Tamil", "English"], online: false, homeVisit: false, slots: ["Thu 09:30", "Fri 16:00"], verified: false, isDemo: true },
  { id: "d4", name: "Dr. Demo Physician", specialty: "General / Internal Medicine", city: "Salem", locality: "Test Street", hospital: "DEMO Family Clinic", languages: ["Tamil"], online: true, homeVisit: true, slots: ["Mon 18:00", "Sat 10:00"], verified: false, isDemo: true },
  { id: "d5", name: "Dr. Demo Pediatrician", specialty: "Pediatrics", city: "Madurai", locality: "Sample Road", hospital: "DEMO Children's Clinic", languages: ["Tamil", "English"], online: true, homeVisit: true, slots: ["Wed 17:00"], verified: false, isDemo: true },
  { id: "d6", name: "Dr. Demo Endocrinologist", specialty: "Endocrinology", city: "Chennai", locality: "Example Nagar", hospital: "DEMO Diabetes Centre", languages: ["English", "Tamil"], online: true, homeVisit: false, slots: ["Tue 14:00"], verified: false, isDemo: true },
  { id: "d7", name: "Dr. Demo Gynecologist", specialty: "Gynecology", city: "Coimbatore", locality: "Sample Colony", hospital: "DEMO Women's Clinic", languages: ["Tamil", "English"], online: true, homeVisit: false, slots: ["Fri 11:30"], verified: false, isDemo: true }
];

export const DEMO_DONORS: Donor[] = [
  { id: "n1", displayName: "Demo Donor 1", group: "A+", city: "Chennai", locality: "Sample Nagar", available: true, consentToMatch: true, lastDonation: "2025-01-10", verified: false, isDemo: true },
  { id: "n2", displayName: "Demo Donor 2", group: "A-", city: "Chennai", available: true, consentToMatch: true, verified: false, isDemo: true },
  { id: "n3", displayName: "Demo Donor 3", group: "O+", city: "Chennai", available: true, consentToMatch: true, verified: false, isDemo: true },
  { id: "n4", displayName: "Demo Donor 4", group: "A+", city: "Chennai", available: true, consentToMatch: false, verified: false, isDemo: true },
  { id: "n5", displayName: "Demo Donor 5", group: "A+", city: "Salem", available: true, consentToMatch: true, verified: false, isDemo: true },
  { id: "n6", displayName: "Demo Donor 6", group: "B+", city: "Chennai", available: false, consentToMatch: true, verified: false, isDemo: true }
];

export const DEMO_REQUESTS: BloodRequest[] = [];
