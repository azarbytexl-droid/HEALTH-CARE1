import { createClient } from "@supabase/supabase-js";

export const supabaseConfigured = () => Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);

/** Client acting as the signed-in user (RLS applies). Pass the user's access token. */
export function supabaseForUser(accessToken: string) {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    global: { headers: { Authorization: `Bearer ${accessToken}` } },
    auth: { persistSession: false }
  });
}

/** Service-role client: server-only, bypasses RLS. Use sparingly and re-check authorization yourself. */
export function supabaseAdmin() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, { auth: { persistSession: false } });
}

export async function getUserFromRequest(req: Request) {
  if (!supabaseConfigured()) return null;
  const token = req.headers.get("authorization")?.replace(/^Bearer /i, "");
  if (!token) return null;
  const { data, error } = await supabaseForUser(token).auth.getUser(token);
  return error ? null : { user: data.user, token };
}
