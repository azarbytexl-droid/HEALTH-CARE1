export type AppointmentStatus = "requested" | "confirmed" | "rejected" | "cancelled" | "rescheduled" | "completed";

const T: Record<AppointmentStatus, AppointmentStatus[]> = {
  requested: ["confirmed", "rejected", "cancelled"],
  confirmed: ["cancelled", "rescheduled", "completed"],
  rescheduled: ["confirmed", "cancelled"],
  rejected: [],
  cancelled: [],
  completed: []
};

export const canTransition = (from: AppointmentStatus, to: AppointmentStatus) => T[from].includes(to);

/** Only providers may confirm/reject/complete; patients may cancel or request reschedule. */
export function canActorTransition(actor: "patient" | "provider" | "admin", from: AppointmentStatus, to: AppointmentStatus) {
  if (!canTransition(from, to)) return false;
  if (actor === "patient") return to === "cancelled" || to === "rescheduled";
  return true;
}
