"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import { Activity, Droplets, FileText, Home, Menu, MessageCircle, Pill, Salad, Settings, ShieldAlert, Siren, Stethoscope, X } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";
import type { Key } from "@/lib/i18n/dictionary";

const NAV: { href: string; key: Key; icon: ReactNode }[] = [
  { href: "/dashboard", key: "nav.dashboard", icon: <Home size={18} /> },
  { href: "/records", key: "nav.records", icon: <FileText size={18} /> },
  { href: "/doctors", key: "nav.doctors", icon: <Stethoscope size={18} /> },
  { href: "/medicines", key: "nav.medicines", icon: <Pill size={18} /> },
  { href: "/wellness", key: "nav.wellness", icon: <Salad size={18} /> },
  { href: "/sos", key: "nav.sos", icon: <Siren size={18} /> },
  { href: "/blood", key: "nav.blood", icon: <Droplets size={18} /> },
  { href: "/chat", key: "nav.chat", icon: <MessageCircle size={18} /> },
  { href: "/settings", key: "nav.settings", icon: <Settings size={18} /> },
  { href: "/legal", key: "nav.legal", icon: <ShieldAlert size={18} /> }
];

export function Shell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const { t, lang, setLang } = useI18n();
  const [open, setOpen] = useState(false);
  if (path === "/") return <>{children}</>;

  const nav = (
    <nav aria-label="Main" className="flex flex-col gap-1">
      {NAV.map((n) => {
        const active = path.startsWith(n.href);
        return (
          <Link key={n.href} href={n.href} onClick={() => setOpen(false)} aria-current={active ? "page" : undefined}
            className={`flex items-center gap-3 rounded-2xl px-4 py-2.5 font-semibold ${active ? "bg-white/15 text-white" : "text-[#b7b0cc] hover:bg-white/10"}`}>
            {n.icon}{t(n.key)}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="mx-auto flex min-h-screen max-w-7xl gap-6 p-4 md:p-6">
      <aside className="glass sticky top-6 hidden h-[calc(100vh-3rem)] w-64 shrink-0 flex-col justify-between p-4 md:flex">
        <div>
          <Link href="/" className="mb-6 flex items-center gap-2 px-2 text-lg font-extrabold"><Activity className="text-[#ff00c8]" />{t("app.name")}</Link>
          {nav}
        </div>
        <LangSwitch lang={lang} setLang={setLang} label={t("common.language")} />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col gap-4">
        <header className="glass flex items-center justify-between p-3 md:hidden">
          <Link href="/" className="flex items-center gap-2 font-extrabold"><Activity className="text-[#ff00c8]" />{t("app.name")}</Link>
          <button className="btn btn-ghost" aria-expanded={open} aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X size={18} /> : <Menu size={18} />}</button>
        </header>
        {open && <div className="glass p-3 md:hidden">{nav}<div className="mt-3"><LangSwitch lang={lang} setLang={setLang} label={t("common.language")} /></div></div>}
        <main id="main" className="min-w-0 flex-1">{children}</main>
        <p className="muted pb-2 text-center text-xs">{t("disclaimer.short")}</p>
      </div>
    </div>
  );
}

function LangSwitch({ lang, setLang, label }: { lang: "en" | "ta"; setLang: (l: "en" | "ta") => void; label: string }) {
  return (
    <div role="group" aria-label={label} className="flex gap-2">
      <button className={`btn ${lang === "en" ? "" : "btn-ghost"}`} aria-pressed={lang === "en"} onClick={() => setLang("en")}>English</button>
      <button className={`btn ${lang === "ta" ? "" : "btn-ghost"}`} aria-pressed={lang === "ta"} onClick={() => setLang("ta")}>தமிழ்</button>
    </div>
  );
}
