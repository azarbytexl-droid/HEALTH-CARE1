import type { ReactNode } from "react";

export function Card({ children, className = "", float = false }: { children: ReactNode; className?: string; float?: boolean }) {
  return <section className={`glass p-5 ${float ? "float-card" : ""} ${className}`}>{children}</section>;
}
export function PageTitle({ children, sub }: { children: ReactNode; sub?: ReactNode }) {
  return <div className="mb-5"><h1 className="text-3xl md:text-4xl">{children}</h1>{sub && <p className="muted mt-1 max-w-2xl">{sub}</p>}</div>;
}
export function DemoTag({ label = "DEMO DATA" }: { label?: string }) { return <span className="tag tag-demo">{label}</span>; }
export function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block"><span className="label">{label}</span>{children}</label>;
}
