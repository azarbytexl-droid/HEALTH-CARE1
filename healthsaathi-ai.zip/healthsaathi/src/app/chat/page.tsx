"use client";
import { useRef, useState } from "react";
import { useI18n } from "@/lib/i18n/provider";
import { Card, PageTitle } from "@/components/ui";

type Msg = { role: "user" | "assistant"; content: string; mode?: "live" | "demo" | "error" | "emergency" };

export default function Chat() {
  const { t, lang } = useI18n();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState(""); const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const q = text.trim(); if (!q || busy) return;
    const next: Msg[] = [...msgs, { role: "user", content: q }];
    setMsgs(next); setText(""); setBusy(true);
    try {
      const res = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ lang, messages: next.map(({ role, content }) => ({ role, content })) }) });
      const json = await res.json();
      setMsgs([...next, { role: "assistant", content: json.text ?? json.error ?? "Something went wrong.", mode: json.mode ?? "error" }]);
    } catch { setMsgs([...next, { role: "assistant", content: "Network error. Please try again.", mode: "error" }]); }
    finally { setBusy(false); setTimeout(() => end.current?.scrollIntoView({ behavior: "smooth" }), 50); }
  }

  return (
    <>
      <PageTitle sub={t("chat.ai")}>{t("chat.title")}</PageTitle>
      <Card className="flex min-h-[50vh] flex-col">
        <div className="flex-1 space-y-3" aria-live="polite">
          {msgs.length === 0 && <p className="muted">Try: “What does HbA1c mean?” or “Which specialist deals with kidney problems?”</p>}
          {msgs.map((m, i) => (
            <div key={i} className={`max-w-[85%] rounded-2xl px-4 py-3 ${m.role === "user" ? "ml-auto bg-gradient-to-r from-[#ff00c8]/40 to-[#6f00ff]/40" : "bg-black/40"} ${m.mode === "emergency" ? "border border-[#ff2d55]" : ""}`}>
              {m.mode === "demo" && <span className="tag tag-demo mb-1">DEMO: not a live AI answer</span>}
              {m.mode === "emergency" && <span className="tag tag-warn mb-1">Possible emergency</span>}
              <p className="whitespace-pre-wrap">{m.content}</p>
              {m.mode === "emergency" && <a href="tel:112" className="btn btn-danger mt-2">{t("sos.call")}</a>}
            </div>
          ))}
          <div ref={end} />
        </div>
        <form onSubmit={send} className="mt-4 flex gap-2">
          <input className="input" aria-label={t("chat.placeholder")} placeholder={t("chat.placeholder")} value={text} maxLength={2000} onChange={(e) => setText(e.target.value)} />
          <button className="btn" disabled={busy}>{t("chat.send")}</button>
        </form>
        {msgs.length > 0 && <button className="btn btn-ghost mt-3 self-start" onClick={() => setMsgs([])}>{t("chat.clear")}</button>}
      </Card>
    </>
  );
}
