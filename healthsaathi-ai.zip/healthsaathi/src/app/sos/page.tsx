"use client";
import { useState } from "react";
import { PhoneCall } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";
import { useLocalState } from "@/lib/useLocalState";
import { Card, Field, PageTitle } from "@/components/ui";

type Contact = { id: string; name: string; phone: string };
type EventRec = { id: string; at: string; status: string; location?: string };

export default function Sos() {
  const { t } = useI18n();
  const [contacts, setContacts] = useLocalState<Contact[]>("hs-contacts", []);
  const [events, setEvents] = useLocalState<EventRec[]>("hs-sos-events", []);
  const [name, setName] = useState(""); const [phone, setPhone] = useState("");
  const [confirmed, setConfirmed] = useState(false); const [shareLoc, setShareLoc] = useState(false);
  const [link, setLink] = useState<string | null>(null);

  function addContact(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !/^\+?[0-9 ]{8,15}$/.test(phone.trim())) return;
    setContacts([...contacts, { id: crypto.randomUUID(), name: name.trim(), phone: phone.replace(/\s/g, "") }]);
    setName(""); setPhone("");
  }

  function prepareAlert() {
    const build = (loc?: string) => {
      const body = encodeURIComponent(`Emergency: I need help. ${loc ? `My location: ${loc}` : ""}`);
      const numbers = contacts.map((c) => c.phone).join(",");
      setLink(`sms:${numbers}?body=${body}`);
      setEvents([{ id: crypto.randomUUID(), at: new Date().toISOString(), status: "Alert prepared. NOT sent automatically.", location: loc }, ...events]);
    };
    if (shareLoc && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (p) => build(`https://maps.google.com/?q=${p.coords.latitude},${p.coords.longitude}`),
        () => build(), { timeout: 8000 });
    } else build();
  }

  return (
    <>
      <PageTitle>{t("sos.title")}</PageTitle>
      <Card className="border-[#ff2d55]">
        <p className="mb-4 text-lg font-bold">{t("sos.warning")}</p>
        <a className="btn btn-danger text-xl" href="tel:112"><PhoneCall />{t("sos.call")}</a>
        <p className="muted mt-3 text-sm">Pressing this opens your phone dialer. No call is made until you confirm on your device.</p>
      </Card>

      <Card className="mt-4">
        <h2 className="mb-3 text-xl">{t("sos.contacts")}</h2>
        <form onSubmit={addContact} className="grid gap-3 md:grid-cols-3" noValidate>
          <Field label="Name"><input className="input" value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label="Phone"><input className="input" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+91…" /></Field>
          <div className="flex items-end"><button className="btn" type="submit">{t("common.save")}</button></div>
        </form>
        <ul className="mt-3 space-y-2">
          {contacts.map((c) => (
            <li key={c.id} className="flex items-center justify-between rounded-2xl bg-black/30 px-4 py-2">
              <span>{c.name} · {c.phone}</span>
              <button className="btn btn-ghost" onClick={() => setContacts(contacts.filter((x) => x.id !== c.id))}>{t("common.delete")}</button>
            </li>
          ))}
        </ul>
      </Card>

      <Card className="mt-4">
        <label className="mb-2 flex items-center gap-2"><input type="checkbox" checked={shareLoc} onChange={(e) => setShareLoc(e.target.checked)} />Include my location (asks for permission)</label>
        <label className="mb-3 flex items-center gap-2"><input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />{t("sos.confirm")}</label>
        <button className="btn" disabled={!confirmed || contacts.length === 0} onClick={prepareAlert}>{t("sos.alert")}</button>
        {contacts.length === 0 && <p className="muted mt-2 text-sm">Add at least one contact first.</p>}
        {link && (
          <div className="mt-3" role="status">
            <p className="tag tag-warn">{t("sos.notSent")}</p>
            <p className="mt-2"><a className="btn btn-ghost" href={link}>Open message to contacts</a></p>
          </div>
        )}
        {events.length > 0 && (
          <ul className="muted mt-4 space-y-1 text-sm">{events.slice(0, 5).map((e) => <li key={e.id}>{new Date(e.at).toLocaleString()} · {e.status}</li>)}</ul>
        )}
      </Card>
    </>
  );
}
