import { NextResponse } from "next/server";
import { validateUpload, sniffType, maxBytes } from "@/lib/fileValidation";
import { getOcrProvider, parseMedicalText } from "@/lib/ocr";
import { rateLimit } from "@/lib/rateLimit";
import { getUserFromRequest, supabaseConfigured } from "@/lib/supabase/server";

export const runtime = "nodejs";

export async function POST(req: Request) {
  // Auth: required when Supabase is configured. Without Supabase the app runs in public DEMO mode only.
  const auth = await getUserFromRequest(req);
  if (supabaseConfigured() && !auth) return NextResponse.json({ error: "Please sign in." }, { status: 401 });

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "local";
  if (!rateLimit(`upload:${auth?.user.id ?? ip}`, 10, 60_000)) return NextResponse.json({ error: "Too many uploads. Try again shortly." }, { status: 429 });

  let file: File | null = null;
  try { file = (await req.formData()).get("file") as File | null; } catch { /* fallthrough */ }
  if (!file) return NextResponse.json({ error: "No file received." }, { status: 400 });

  const v = validateUpload({ name: file.name, size: file.size, type: file.type }, maxBytes());
  if (!v.ok) return NextResponse.json({ error: v.error }, { status: 400 });

  const bytes = new Uint8Array(await file.arrayBuffer());
  const real = sniffType(bytes);
  if (!real || real !== file.type) return NextResponse.json({ error: "File content does not match its type." }, { status: 400 });

  try {
    const ocr = getOcrProvider();
    const { text, confidence } = await ocr.extract({ bytes, type: file.type, name: file.name });
    const items = parseMedicalText(text);
    // TODO(production): store bytes in the private "medical-documents" bucket and rows in extracted_medical_records.
    return NextResponse.json({ mode: ocr.isDemo ? "demo" : "live", items, ocrConfidence: confidence });
  } catch {
    return NextResponse.json({ error: "Could not process this document." }, { status: 500 }); // no document content in errors/logs
  }
}
