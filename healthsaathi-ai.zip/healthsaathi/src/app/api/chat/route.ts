import { NextResponse } from "next/server";
import { z } from "zod";
import { askAi } from "@/lib/ai";
import { detectEmergency, EMERGENCY_REPLY } from "@/lib/safety";
import { rateLimit } from "@/lib/rateLimit";

export const runtime = "nodejs";

const Body = z.object({
  lang: z.enum(["en", "ta"]).default("en"),
  messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().min(1).max(2000) })).min(1).max(30)
});

export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "local";
  if (!rateLimit(`chat:${ip}`, 20, 60_000)) return NextResponse.json({ error: "Too many messages. Please wait a moment." }, { status: 429 });

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  const { lang, messages } = parsed.data;

  const last = messages[messages.length - 1];
  // Emergency check runs first, before and independent of any AI call.
  if (last.role === "user" && detectEmergency(last.content)) {
    return NextResponse.json({ mode: "emergency", text: EMERGENCY_REPLY[lang] });
  }
  // Only the chat text is sent. No stored medical records are attached unless a future, explicit consent flow adds them.
  const withLang = [...messages.slice(0, -1), { ...last, content: `${last.content}\n\n(Reply in ${lang === "ta" ? "Tamil" : "English"}.)` }];
  const out = await askAi(withLang);
  return NextResponse.json({ mode: out.mode, text: out.text }, { status: out.mode === "error" ? 502 : 200 });
}
