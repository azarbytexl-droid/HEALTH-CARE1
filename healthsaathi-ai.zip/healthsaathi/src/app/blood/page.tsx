"use client";
import { useState } from "react";
import { useI18n } from "@/lib/i18n/provider";
import { useLocalState } from "@/lib/useLocalState";
import { Card, DemoTag, Field, PageTitle } from "@/components/ui";
import { BLOOD_GROUPS, isDuplicateRequest, matchDonors, type BloodGroup, type BloodRequest, type Donor } from "@/lib/blood";
import { DEMO_DONORS } from "@/lib/demoData";

type Notice = { id: string; text: string; at: string };

export default function Blood() {
  const { t } = useI18n();
  const [donors, setDonors] = useLocalState<Donor[]>("hs-donors", DEMO_DONORS);
  const [reqs, setReqs] = useLocalState<BloodRequest[]>("hs-bloodreqs", []);
  const [notices, setNotices] = useLocalState<Notice[]>("hs-notices", []);
  const [dn, setDn] = useState({ name: "", group: "O+" as BloodGroup, city: "", consent: false });
  const [rq, setRq] = useState({ group: "A+" as BloodGroup, city: "Chennai", hospital: "", units: "1", urgency: "urgent" as BloodRequest["urgency"] });
  const [msg, setMsg] = useState("");

  function registerDonor(e: React.FormEvent) {
    e.preventDefault();
    if (!dn.name.trim() || !dn.city.trim()) return setMsg(t("common.required"));
    if (!dn.consent) return setMsg(t("blood.consent"));
    setDonors([...donors, { id: crypto.randomUUID(), displayName: dn.name.trim(), group: dn.group, city: dn.city.trim(), available: true, consentToMatch: true, verified: false, isDemo: false }]);
    setDn({ name: "", group: "O+", city: "", consent: false }); setMsg("");
  }

  function createRequest(e: React.FormEvent) {
    e.preventDefault();
    if (!rq.hospital.trim() || !rq.city.trim()) return setMsg(t("common.required"));
    if (isDuplicateRequest(reqs, rq)) return setMsg("An open request for this group, hospital and city already exists.");
    const r: BloodRequest = { id: crypto.randomUUID(), group: rq.group, units: Number(rq.units) || undefined, city: rq.city.trim(), hospital: rq.hospital.trim(), urgency: rq.urgency, status: "open", requiredBy: new Date().toISOString().slice(0, 10), verified: false };
    setReqs([r, ...reqs]);
    // In-app notices only for opted-in, eligible, same-city matches. Never broadcast to all users.
    const m = matchDonors(r, donors);
    setNotices([...m.map((d) => ({ id: crypto.randomUUID(), text: `Notified ${d.displayName}: ${r.group} needed at ${r.hospital}, ${r.city}`, at: new Date().toLocaleString() })), ...notices]);
    setMsg("");
  }

  const close = (id: string, status: BloodRequest["status"]) => setReqs(reqs.map((r) => (r.id === id ? { ...r, status } : r)));

  return (
    <>
      <PageTitle sub={t("blood.confirmNote")}>{t("blood.title")}</PageTitle>
      {msg && <p role="alert" className="mb-3 text-[#ff8aa0]">{msg}</p>}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <h2 className="mb-3 text-xl">{t("blood.register")}</h2>
          <form onSubmit={registerDonor} className="grid gap-3" noValidate>
            <Field label="Display name (no phone numbers are shown publicly)"><input className="input" value={dn.name} onChange={(e) => setDn({ ...dn, name: e.target.value })} /></Field>
            <Field label={t("blood.group")}><select className="input" value={dn.group} onChange={(e) => setDn({ ...dn, group: e.target.value as BloodGroup })}>{BLOOD_GROUPS.map((g) => <option key={g}>{g}</option>)}</select></Field>
            <Field label={t("common.city")}><input className="input" value={dn.city} onChange={(e) => setDn({ ...dn, city: e.target.value })} /></Field>
            <label className="flex items-center gap-2"><input type="checkbox" checked={dn.consent} onChange={(e) => setDn({ ...dn, consent: e.target.checked })} />{t("blood.consent")}</label>
            <button className="btn" type="submit">{t("blood.register")}</button>
          </form>
        </Card>
        <Card>
          <h2 className="mb-3 text-xl">{t("blood.request")}</h2>
          <form onSubmit={createRequest} className="grid gap-3" noValidate>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("blood.group")}><select className="input" value={rq.group} onChange={(e) => setRq({ ...rq, group: e.target.value as BloodGroup })}>{BLOOD_GROUPS.map((g) => <option key={g}>{g}</option>)}</select></Field>
              <Field label="Units"><input className="input" type="number" min={1} max={10} value={rq.units} onChange={(e) => setRq({ ...rq, units: e.target.value })} /></Field>
            </div>
            <Field label="Hospital or blood bank"><input className="input" value={rq.hospital} onChange={(e) => setRq({ ...rq, hospital: e.target.value })} /></Field>
            <Field label={t("common.city")}><input className="input" value={rq.city} onChange={(e) => setRq({ ...rq, city: e.target.value })} /></Field>
            <Field label="Urgency"><select className="input" value={rq.urgency} onChange={(e) => setRq({ ...rq, urgency: e.target.value as BloodRequest["urgency"] })}><option value="routine">Routine</option><option value="urgent">Urgent</option><option value="critical">Critical</option></select></Field>
            <button className="btn" type="submit">{t("blood.request")}</button>
          </form>
        </Card>
      </div>

      {reqs.map((r) => {
        const m = matchDonors(r, donors);
        return (
          <Card key={r.id} className="mt-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-lg">{r.group} · {r.hospital}, {r.city} <span className="tag tag-warn ml-2">{r.status}</span> <span className="tag">unverified</span></h3>
              {r.status === "open" && <span className="flex gap-2"><button className="btn btn-ghost" onClick={() => close(r.id, "fulfilled")}>Mark fulfilled</button><button className="btn btn-ghost" onClick={() => close(r.id, "cancelled")}>{t("common.cancel")}</button></span>}
            </div>
            <h4 className="muted mt-3 text-sm">{t("blood.matches")}</h4>
            {m.length === 0 ? <p className="muted">{t("blood.none")}</p> : (
              <ul className="mt-1 flex flex-wrap gap-2">{m.map((d) => <li key={d.id} className="tag">{d.displayName} · {d.group} {d.isDemo && "· DEMO"}</li>)}</ul>
            )}
          </Card>
        );
      })}

      {notices.length > 0 && (
        <Card className="mt-4">
          <h2 className="mb-2 text-xl">In-app notifications</h2>
          <ul className="muted space-y-1 text-sm">{notices.slice(0, 8).map((n) => <li key={n.id}>{n.at} · {n.text}</li>)}</ul>
        </Card>
      )}
      <p className="muted mt-4 text-xs">Sample donors are labelled <DemoTag label="DEMO" />. Email/SMS/push alerts are not enabled in this build.</p>
    </>
  );
}
