"use client";
import { useMemo, useState } from "react";
import { useI18n } from "@/lib/i18n/provider";
import { useLocalState } from "@/lib/useLocalState";
import { Card, DemoTag, PageTitle } from "@/components/ui";
import { DEMO_DOCTORS, SPECIALTIES } from "@/lib/demoData";

type Appt = { id: string; doctorId: string; doctor: string; slot: string; status: "requested" | "confirmed" | "rejected" | "cancelled" | "rescheduled" | "completed" };

export default function Doctors() {
  const { t } = useI18n();
  const [q, setQ] = useState(""); const [spec, setSpec] = useState(""); const [city, setCity] = useState(""); const [home, setHome] = useState(false);
  const [appts, setAppts] = useLocalState<Appt[]>("hs-appts", []);
  const cities = [...new Set(DEMO_DOCTORS.map((d) => d.city))];

  const list = useMemo(() => DEMO_DOCTORS.filter((d) =>
    (!spec || d.specialty === spec) && (!city || d.city === city) && (!home || d.homeVisit) &&
    (!q || `${d.name} ${d.hospital} ${d.locality} ${d.specialty}`.toLowerCase().includes(q.toLowerCase()))), [q, spec, city, home]);

  const request = (doc: (typeof DEMO_DOCTORS)[number], slot: string) =>
    setAppts([{ id: crypto.randomUUID(), doctorId: doc.id, doctor: doc.name, slot, status: "requested" }, ...appts]);

  return (
    <>
      <PageTitle sub={t("doctors.sampleNote")}>{t("doctors.title")}</PageTitle>
      <Card>
        <div className="grid gap-3 md:grid-cols-4">
          <input className="input" aria-label={t("common.search")} placeholder={t("common.search")} value={q} onChange={(e) => setQ(e.target.value)} />
          <select className="input" aria-label={t("doctors.specialty")} value={spec} onChange={(e) => setSpec(e.target.value)}>
            <option value="">{t("doctors.specialty")}: {t("common.all")}</option>
            {SPECIALTIES.map((s) => <option key={s}>{s}</option>)}
          </select>
          <select className="input" aria-label={t("common.city")} value={city} onChange={(e) => setCity(e.target.value)}>
            <option value="">{t("common.city")}: {t("common.all")}</option>
            {cities.map((c) => <option key={c}>{c}</option>)}
          </select>
          <label className="flex items-center gap-2"><input type="checkbox" checked={home} onChange={(e) => setHome(e.target.checked)} />{t("doctors.home")}</label>
        </div>
      </Card>
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        {list.length === 0 && <Card><p className="muted">No sample doctors match these filters.</p></Card>}
        {list.map((d) => (
          <Card key={d.id} float>
            <div className="flex flex-wrap items-center gap-2"><h2 className="text-lg">{d.name}</h2><DemoTag label="SAMPLE / DEMO" /></div>
            <p className="muted text-sm">{d.specialty} · {d.hospital} · {d.locality}, {d.city}</p>
            <p className="mt-1 text-sm">{d.languages.join(", ")} · {d.online ? "Online" : "In-person only"}{d.homeVisit ? " · Home visit (needs provider confirmation)" : ""}</p>
            <p className="muted mt-1 text-xs">Not a verified provider. No registration number.</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {d.slots.map((s) => {
                const done = appts.some((a) => a.doctorId === d.id && a.slot === s && a.status === "requested");
                return <button key={s} className="btn btn-ghost" disabled={done} onClick={() => request(d, s)}>{done ? "Requested" : `${t("doctors.request")}: ${s}`}</button>;
              })}
            </div>
          </Card>
        ))}
      </div>
      {appts.length > 0 && (
        <Card className="mt-4">
          <h2 className="mb-2 text-xl">{t("dash.upcoming")}</h2>
          <p className="muted mb-2 text-sm">{t("doctors.requested")}</p>
          <ul className="space-y-2">
            {appts.map((a) => (
              <li key={a.id} className="flex items-center justify-between rounded-2xl bg-black/30 px-4 py-3">
                <span>{a.doctor} · {a.slot} <span className="tag tag-warn ml-2">{a.status}</span></span>
                {a.status === "requested" && <button className="btn btn-ghost" onClick={() => setAppts(appts.map((x) => (x.id === a.id ? { ...x, status: "cancelled" } : x)))}>{t("common.cancel")}</button>}
              </li>
            ))}
          </ul>
        </Card>
      )}
    </>
  );
}
