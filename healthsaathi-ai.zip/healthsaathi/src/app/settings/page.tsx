"use client";
import { useState } from "react";
import { useI18n } from "@/lib/i18n/provider";
import { useLocalState } from "@/lib/useLocalState";
import { Card, Field, PageTitle } from "@/components/ui";

const KEYS = ["hs-records", "hs-appts", "hs-meds", "hs-adherence", "hs-wellness", "hs-contacts", "hs-sos-events", "hs-donors", "hs-bloodreqs", "hs-notices"];

export default function Settings() {
  const { t } = useI18n();
  const [consent, setConsent] = useLocalState<boolean>("hs-ai-consent", false);
  const [abha, setAbha] = useLocalState<string>("hs-abha-mock", "");
  const [done, setDone] = useState("");

  function exportData() {
    const data: Record<string, unknown> = {};
    KEYS.forEach((k) => { const v = localStorage.getItem(k); if (v) data[k] = JSON.parse(v); });
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    const a = document.createElement("a"); a.href = url; a.download = "healthsaathi-export.json"; a.click(); URL.revokeObjectURL(url);
  }
  function wipe() {
    if (!confirm("Delete all local demo data on this device?")) return;
    KEYS.forEach((k) => localStorage.removeItem(k)); setDone("Local demo data deleted. Reload to see the reset state.");
  }

  return (
    <>
      <PageTitle sub="Data is stored only in this browser while running in demo mode.">{t("settings.title")}</PageTitle>
      <Card>
        <label className="mb-4 flex items-center gap-2"><input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />{t("settings.consent")}</label>
        <Field label={t("settings.abha")}><input className="input max-w-sm" value={abha} onChange={(e) => setAbha(e.target.value)} placeholder="demo only" /></Field>
        <p className="muted mt-1 text-xs">No ABDM/ABHA integration exists in this app. This is a placeholder field.</p>
        <div className="mt-5 flex flex-wrap gap-3">
          <button className="btn" onClick={exportData}>{t("settings.export")}</button>
          <button className="btn btn-ghost" onClick={wipe}>{t("settings.delete")}</button>
        </div>
        {done && <p role="status" className="mt-3">{done}</p>}
      </Card>
    </>
  );
}
