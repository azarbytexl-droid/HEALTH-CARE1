import { Card, PageTitle } from "@/components/ui";

export default function Legal() {
  return (
    <>
      <PageTitle>Medical disclaimer, privacy & terms</PageTitle>
      <Card className="space-y-3">
        <p><b>Not medical advice.</b> HealthSaathi AI is an educational hackathon demo. It does not diagnose, prescribe or replace a doctor, pharmacist or blood bank.</p>
        <p><b>Emergencies.</b> Call 112 immediately for life-threatening situations.</p>
        <p><b>Sample data.</b> All doctors, donors, phone numbers and reports shown are fictional DEMO data.</p>
        <p><b>Privacy.</b> Demo mode keeps data in your browser only. Before real deployment, obtain legal review for India&apos;s Digital Personal Data Protection Act, 2023, and applicable health-data rules. This project makes no legal-compliance claim.</p>
        <p><b>ABDM / FHIR.</b> The data model is FHIR-inspired. There is no official ABDM integration or FHIR conformance claim.</p>
      </Card>
    </>
  );
}
