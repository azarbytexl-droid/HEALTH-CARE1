"use client";
import { useState } from "react";
import { useI18n } from "@/lib/i18n/provider";
import { useLocalState } from "@/lib/useLocalState";
import { Card, PageTitle } from "@/components/ui";
import type { Extracted } from "@/lib/ocr";
import { validateUpload } from "@/lib/fileValidation";

type SavedRecord = { id: string; title: string; date: string; abnormal: number; items: Extracted[] };
type UploadResult = { mode: "demo" | "live"; items: Extracted[]; ocrConfidence?: number };

export default function Records() {
  const { t } = useI18n();
  const [saved, setSaved] = useLocalState<SavedRecord[]>("hs-records", []);
  const [result, setResult] = useState<UploadResult | null>(null);
  const [items, setItems] = useState<Extracted[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function onFile(f: File | undefined) {
    if (!f) return;
    setError(""); setResult(null);
    const v = validateUpload({ name: f.name, size: f.size, type: f.type }, 10 * 1048576);
    if (!v.ok) { setError(v.error); return; }
    setBusy(true);
    try {
      const fd = new FormData(); fd.append("file", f);
      const res = await fetch("/api/records/upload", { method: "POST", body: fd });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Upload failed");
      setResult(json); setItems(json.items);
    } catch (e) { setError(e instanceof Error ? e.message : "Upload failed"); }
    finally { setBusy(false); }
  }

  function approve() {
    const abnormal = items.filter((i) => i.flag === "low" || i.flag === "high").length;
    setSaved([{ id: crypto.randomUUID(), title: result?.mode === "demo" ? "Sample lab report (DEMO)" : "Uploaded report", date: new Date().toISOString().slice(0, 10), abnormal, items }, ...saved]);
    setResult(null); setItems([]);
  }

  return (
    <>
      <PageTitle sub={t("records.hint")}>{t("records.title")}</PageTitle>
      <Card>
        <label className="label" htmlFor="file">{t("records.upload")}</label>
        <input id="file" className="input" type="file" accept="application/pdf,image/png,image/jpeg,image/webp" onChange={(e) => onFile(e.target.files?.[0])} />
        {busy && <p className="muted mt-3" role="status">Processing…</p>}
        {error && <p className="mt-3 text-[#ff8aa0]" role="alert">{error}</p>}
      </Card>

      {result && (
        <Card className="mt-4">
          <div className="mb-2 flex flex-wrap items-center gap-2">
            <h2 className="text-xl">{t("records.extracted")}</h2>
            {result.mode === "demo" && <span className="tag tag-demo">DEMO OCR: sample text, not read from your file</span>}
          </div>
          <p className="muted mb-3 text-sm">{t("records.review")}</p>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="muted"><tr><th className="p-2">Name</th><th className="p-2">Value</th><th className="p-2">Unit</th><th className="p-2">Lab range</th><th className="p-2">Flag</th><th className="p-2">Confidence</th></tr></thead>
              <tbody>
                {items.map((it, idx) => (
                  <tr key={idx} className={it.needsReview ? "bg-[#ffbe0014]" : ""}>
                    <td className="p-2">{it.name}</td>
                    <td className="p-2"><input aria-label={`Value for ${it.name}`} className="input !py-1" value={it.value ?? ""} onChange={(e) => setItems(items.map((x, i) => (i === idx ? { ...x, value: e.target.value, needsReview: false } : x)))} /></td>
                    <td className="p-2">{it.unit ?? "—"}</td>
                    <td className="p-2">{it.refLow !== undefined ? `${it.refLow} – ${it.refHigh}` : "—"}</td>
                    <td className="p-2">{it.flag === "high" || it.flag === "low" ? <span className="tag tag-warn">{it.flag}</span> : it.flag === "within" ? <span className="tag tag-ok">within</span> : "—"}</td>
                    <td className="p-2">{it.needsReview ? <span className="tag tag-warn">review · {Math.round(it.confidence * 100)}%</span> : `${Math.round(it.confidence * 100)}%`}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {items.some((i) => i.flag === "high" || i.flag === "low") && <p className="mt-3 text-sm">{t("records.outOfRange")}</p>}
          <p className="muted mt-3 text-xs">{t("records.explain")}: this build shows extracted facts only. Connect an AI key to generate explanations; they will be labelled AI-generated.</p>
          <button className="btn mt-4" onClick={approve}>{t("records.approve")}</button>
        </Card>
      )}

      <Card className="mt-4">
        <h2 className="mb-3 text-xl">{t("nav.records")}</h2>
        {saved.length === 0 ? <p className="muted">{t("dash.empty")}</p> : (
          <ul className="space-y-2">
            {saved.map((r) => (
              <li key={r.id} className="flex items-center justify-between rounded-2xl bg-black/30 px-4 py-3">
                <span>{r.title} <span className="muted text-sm">· {r.date} · {r.items.length} items · {r.abnormal} outside range</span></span>
                <button className="btn btn-ghost" onClick={() => { if (confirm("Delete this record?")) setSaved(saved.filter((x) => x.id !== r.id)); }}>{t("common.delete")}</button>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </>
  );
}
