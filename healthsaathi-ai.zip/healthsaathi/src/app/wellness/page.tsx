"use client";
import { useI18n } from "@/lib/i18n/provider";
import { useLocalState } from "@/lib/useLocalState";
import { Card, Field, PageTitle } from "@/components/ui";
import { todayISO } from "@/lib/schedule";

type Day = { date: string; water: number; sleep: string; activity: string; meals: Record<string, boolean>; allergies: string; times: Record<string, string> };
const fresh = (): Day => ({ date: todayISO(), water: 0, sleep: "", activity: "", meals: { breakfast: false, lunch: false, dinner: false, snack: false }, allergies: "", times: { breakfast: "08:00", lunch: "13:00", dinner: "20:00", snack: "17:00" } });

export default function Wellness() {
  const { t } = useI18n();
  const [day, setDay] = useLocalState<Day>("hs-wellness", fresh());
  const d = day.date === todayISO() ? day : { ...fresh(), allergies: day.allergies, times: day.times }; // new day resets progress, keeps settings
  const done = Object.values(d.meals).filter(Boolean).length + (d.water >= 8 ? 1 : 0);
  const total = Object.keys(d.meals).length + 1;
  const set = (p: Partial<Day>) => setDay({ ...d, ...p });

  return (
    <>
      <PageTitle sub={t("well.note")}>{t("well.title")}</PageTitle>
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <h2 className="mb-3 text-xl">Checklist · {done}/{total}</h2>
          {Object.keys(d.meals).map((m) => (
            <div key={m} className="mb-2 flex items-center justify-between gap-3">
              <label className="flex items-center gap-2 capitalize"><input type="checkbox" checked={d.meals[m]} onChange={(e) => set({ meals: { ...d.meals, [m]: e.target.checked } })} />{m}</label>
              <input aria-label={`${m} time`} type="time" className="input !w-32" value={d.times[m]} onChange={(e) => set({ times: { ...d.times, [m]: e.target.value } })} />
            </div>
          ))}
          <div className="mt-4 flex items-center gap-3">
            <span>{t("well.water")}: <b>{d.water}</b></span>
            <button className="btn btn-ghost" aria-label="Add a glass" onClick={() => set({ water: d.water + 1 })}>+1</button>
            <button className="btn btn-ghost" aria-label="Remove a glass" onClick={() => set({ water: Math.max(0, d.water - 1) })}>−1</button>
          </div>
        </Card>
        <Card>
          <div className="grid gap-3">
            <Field label={t("well.sleep")}><input type="number" min={0} max={24} className="input" value={d.sleep} onChange={(e) => set({ sleep: e.target.value })} /></Field>
            <Field label={t("well.activity")}><input type="number" min={0} max={1440} className="input" value={d.activity} onChange={(e) => set({ activity: e.target.value })} /></Field>
            <Field label={t("well.allergies")}><input className="input" value={d.allergies} onChange={(e) => set({ allergies: e.target.value })} /></Field>
          </div>
          {d.allergies && <p className="tag tag-warn mt-3">Allergy noted: {d.allergies}. Check every suggestion against it and ask your clinician.</p>}
          <p className="muted mt-3 text-xs">Example ideas (general education, not a therapeutic diet): idli with sambar, vegetable pongal, curd rice with salad, dal and vegetables, grilled fish or eggs for non-vegetarian days.</p>
        </Card>
      </div>
    </>
  );
}
