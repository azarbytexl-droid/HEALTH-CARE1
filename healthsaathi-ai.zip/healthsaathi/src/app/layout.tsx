import type { Metadata, Viewport } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { I18nProvider } from "@/lib/i18n/provider";
import { Shell } from "@/components/Shell";

const jakarta = Plus_Jakarta_Sans({ subsets: ["latin"], weight: ["400", "600", "800"], variable: "--font-jakarta" });

export const metadata: Metadata = { title: "HealthSaathi AI", description: "Personal health copilot (hackathon demo)" };
export const viewport: Viewport = { themeColor: "#050505" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={jakarta.variable}>
      <body>
        <div className="fluid" aria-hidden="true"><i /><i /><i /></div>
        <div className="grain" aria-hidden="true" />
        <I18nProvider><Shell>{children}</Shell></I18nProvider>
      </body>
    </html>
  );
}
