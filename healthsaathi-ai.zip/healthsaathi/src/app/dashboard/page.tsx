"use client";
import Link from "next/link";
import { useI18n } from "@/lib/i18n/provider";
import { useLocalState } from "@/lib/useLocalState";
import { Card, PageTitle } from "@/components/ui";
import { dosesForDate, todayISO, type Schedule } from "@/lib/schedule";

type SavedRecord = { id: string; title: string; date: string; abnormal: number };
type Appt = { id: string; doctor: string; slot: string; status: string };

export default function Dashboard() {
  const { t } = useI18n();
  const [records] = useLocalState<SavedRecord[]>("hs-records", []);
  const [appts] = useLocalState<Appt[]>("hs-appts", []);
  const [meds] = useLocalState<Schedule[]>("hs-meds", []);
  const doses = meds.flatMap((m) => dosesForDate(m, todayISO()));
  const timeline = [
    ...records.map((r) => ({ id: r.id, date: r.date, label: r.title, kind: "Report" })),
    ...appts.map((a) => ({ id: a.id, date: a.slot, label: `${a.doctor} (${a.status})`, kind: "Appointment" }))
  ].sort((a, b) => b.date.localeCompare(a.date));

  return (
    <>
      <PageTitle sub={t("disclaimer.short")}>{t("dash.title")}</PageTitle>
      <div className="grid gap-4 md:grid-cols-3">
        <Card float><p className="muted text-sm">{t("nav.records")}</p><p className="text-4xl font-extrabold">{records.length}</p></Card>
        <Card float><p className="muted text-sm">{t("dash.upcoming")}</p><p className="text-4xl font-extrabold">{appts.length}</p></Card>
        <Card float><p className="muted text-sm">{t("dash.todayDoses")}</p><p className="text-4xl font-extrabold">{doses.length}</p></Card>
      </div>
      <Card className="mt-4">
        <h2 className="mb-3 text-xl">{t("dash.timeline")}</h2>
        {timeline.length === 0 ? (
          <p className="muted">{t("dash.empty")} <Link className="underline" href="/records">{t("records.upload")}</Link></p>
        ) : (
          <ol className="space-y-2">
            {timeline.map((e) => (
              <li key={e.id} className="flex items-center justify-between rounded-2xl bg-black/30 px-4 py-3">
                <span>{e.label}</span><span className="muted text-sm">{e.kind} · {e.date}</span>
              </li>
            ))}
          </ol>
        )}
      </Card>
    </>
  );
}
