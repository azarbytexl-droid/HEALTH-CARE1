"use client";
import Link from "next/link";
import { Activity, Droplets, FileText, Siren } from "lucide-react";
import { useI18n } from "@/lib/i18n/provider";

export default function Landing() {
  const { t, lang, setLang } = useI18n();
  return (
    <div className="mx-auto max-w-6xl px-5 py-8">
      <header className="flex items-center justify-between">
        <span className="flex items-center gap-2 text-lg font-extrabold"><Activity className="text-[#ff00c8]" />{t("app.name")}</span>
        <div className="flex gap-2" role="group" aria-label="Language">
          <button className={`btn ${lang === "en" ? "" : "btn-ghost"}`} aria-pressed={lang === "en"} onClick={() => setLang("en")}>English</button>
          <button className={`btn ${lang === "ta" ? "" : "btn-ghost"}`} aria-pressed={lang === "ta"} onClick={() => setLang("ta")}>தமிழ்</button>
        </div>
      </header>
      <main className="grid items-center gap-10 py-16 md:grid-cols-[1.2fr_1fr]">
        <div>
          <h1 className="text-4xl leading-[1.05] md:text-6xl">{t("landing.title")}</h1>
          <p className="muted mt-5 max-w-xl text-lg">{t("landing.sub")}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/dashboard" className="btn">{t("landing.cta")}</Link>
            <Link href="/sos" className="btn btn-danger"><Siren size={18} />{t("nav.sos")}</Link>
          </div>
          <p className="muted mt-6 max-w-xl text-sm">{t("disclaimer.short")}</p>
        </div>
        <div className="grid gap-4">
          <div className="glass float-card p-5"><FileText className="mb-2 text-[#ff00c8]" /><p className="font-bold">Haemoglobin 11.2 g/dL</p><p className="muted text-sm">Lab range 13.0 – 17.0 · SAMPLE</p></div>
          <div className="glass float-card ml-8 p-5"><Droplets className="mb-2 text-[#6f00ff]" /><p className="font-bold">A+ request · Chennai</p><p className="muted text-sm">2 opted-in donors matched · DEMO</p></div>
        </div>
      </main>
    </div>
  );
}
