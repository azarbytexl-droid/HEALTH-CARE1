"use client";
import { useEffect, useState } from "react";
import { useI18n } from "@/lib/i18n/provider";
import { useLocalState } from "@/lib/useLocalState";
import { Card, Field, PageTitle } from "@/components/ui";
import { adherenceSummary, dosesForDate, isValidTime, todayISO, type DoseStatus, type Schedule } from "@/lib/schedule";

export default function Medicines() {
  const { t } = useI18n();
  const [meds, setMeds] = useLocalState<Schedule[]>("hs-meds", []);
  const [log, setLog] = useLocalState<Record<string, DoseStatus>>("hs-adherence", {});
  const [name, setName] = useState(""); const [dosage, setDosage] = useState(""); const [times, setTimes] = useState("");
  const [err, setErr] = useState(""); const [perm, setPerm] = useState<string>("default");
  useEffect(() => { if (typeof Notification !== "undefined") setPerm(Notification.permission); }, []);

  const today = todayISO();
  const doses = meds.flatMap((m) => dosesForDate(m, today)).sort((a, b) => a.time.localeCompare(b.time));
  const sum = adherenceSummary(doses, log);

  // In-tab reminders only while the page is open. Real background reminders need a scheduled backend job (see README).
  useEffect(() => {
    if (perm !== "granted") return;
    const id = setInterval(() => {
      const now = new Date(); const hhmm = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
      meds.filter((m) => m.reminders).flatMap((m) => dosesForDate(m, todayISO())).filter((d) => d.time === hhmm && !log[d.key])
        .forEach((d) => new Notification(`${d.medicine}`, { body: `${d.dosage} · ${d.time}` }));
    }, 30_000);
    return () => clearInterval(id);
  }, [perm, meds, log]);

  function add(e: React.FormEvent) {
    e.preventDefault();
    const ts = times.split(",").map((s) => s.trim()).filter(Boolean);
    if (!name.trim() || !dosage.trim() || ts.length === 0) { setErr(t("common.required")); return; }
    if (!ts.every(isValidTime)) { setErr("Use HH:MM (24-hour), e.g. 08:00, 20:00."); return; }
    setErr("");
    setMeds([...meds, { id: crypto.randomUUID(), medicine: name.trim(), dosage: dosage.trim(), times: ts, startDate: today, reminders: true }]);
    setName(""); setDosage(""); setTimes("");
  }

  return (
    <>
      <PageTitle sub={t("med.unclear")}>{t("med.title")}</PageTitle>
      <Card>
        <form onSubmit={add} className="grid gap-3 md:grid-cols-4" noValidate>
          <Field label={t("med.name")}><input className="input" value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label={t("med.dosage")}><input className="input" value={dosage} onChange={(e) => setDosage(e.target.value)} placeholder="as written on the prescription" /></Field>
          <Field label={t("med.times")}><input className="input" value={times} onChange={(e) => setTimes(e.target.value)} placeholder="08:00, 20:00" /></Field>
          <div className="flex items-end"><button className="btn" type="submit">{t("med.add")}</button></div>
        </form>
        {err && <p role="alert" className="mt-2 text-[#ff8aa0]">{err}</p>}
        <p className="muted mt-3 text-xs">You enter the doses and times from your prescription. HealthSaathi never chooses or changes a dose.</p>
      </Card>

      <Card className="mt-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-xl">{t("dash.todayDoses")} · {sum.taken}/{sum.total}</h2>
          {typeof Notification !== "undefined" && perm !== "granted" && <button className="btn btn-ghost" onClick={async () => setPerm(await Notification.requestPermission())}>{t("med.notify")}</button>}
        </div>
        {doses.length === 0 ? <p className="muted">{t("dash.empty")}</p> : (
          <ul className="space-y-2">
            {doses.map((d) => (
              <li key={d.key} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-black/30 px-4 py-3">
                <span><b>{d.time}</b> · {d.medicine} · {d.dosage}</span>
                <span className="flex gap-2">
                  <button className={`btn ${log[d.key] === "taken" ? "" : "btn-ghost"}`} onClick={() => setLog({ ...log, [d.key]: "taken" })}>{t("med.taken")}</button>
                  <button className={`btn ${log[d.key] === "skipped" ? "" : "btn-ghost"}`} onClick={() => setLog({ ...log, [d.key]: "skipped" })}>{t("med.skipped")}</button>
                </span>
              </li>
            ))}
          </ul>
        )}
        {meds.length > 0 && <button className="btn btn-ghost mt-4" onClick={() => { if (confirm("Remove all medicines?")) setMeds([]); }}>{t("common.delete")}</button>}
      </Card>
    </>
  );
}
