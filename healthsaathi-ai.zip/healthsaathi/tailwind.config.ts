import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { ink: "#050505", pink: { DEFAULT: "#ff00c8" }, violet: { DEFAULT: "#6f00ff" } },
      fontFamily: { sans: ["var(--font-jakarta)", "system-ui", "sans-serif"] }
    }
  },
  plugins: []
};
export default config;
