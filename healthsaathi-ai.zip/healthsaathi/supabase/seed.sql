-- DEMO seed only. All records are fictional.
insert into doctor_specialties (name) values
('Cardiology'),('Neurology'),('Neurosurgery'),('Pulmonology'),('Gastroenterology'),('Hepatology'),('Nephrology'),('Urology'),
('Endocrinology'),('Dermatology'),('Orthopedics'),('Rheumatology'),('Gynecology'),('Obstetrics'),('Pediatrics'),('Neonatology'),
('Ophthalmology'),('ENT / Otolaryngology'),('Dentistry'),('Oncology'),('Hematology'),('Psychiatry'),('Psychology'),
('General / Internal Medicine'),('Family Medicine'),('Geriatrics'),('Infectious Disease'),('Physical Medicine and Rehabilitation'),
('Physiotherapy'),('Nutrition and Dietetics'),('Emergency Medicine'),('Anesthesiology and Pain Medicine'),('Palliative Care')
on conflict do nothing;
insert into hospitals (name, city, locality, maternity, is_demo) values
('DEMO Heart Centre','Chennai','Sample Nagar',false,true),
('DEMO Maternity Hospital','Chennai','Example Park',true,true),
('DEMO Family Clinic','Salem','Test Street',false,true);
insert into doctors (full_name, specialty_id, hospital_id, languages, online, home_visit, is_demo)
select 'Dr. Demo Cardiologist', s.id, h.id, '{English,Tamil}', true, false, true
from doctor_specialties s, hospitals h where s.name='Cardiology' and h.name='DEMO Heart Centre';
