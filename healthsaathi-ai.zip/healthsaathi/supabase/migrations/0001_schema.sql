-- HealthSaathi AI schema. FHIR-inspired (not FHIR-conformant). Run in Supabase SQL editor or `supabase db push`.
create extension if not exists pgcrypto;

create type app_role as enum ('patient','doctor','admin');
create type appt_status as enum ('requested','confirmed','rejected','cancelled','rescheduled','completed');
create type home_status as enum ('pending','accepted','rejected','completed','cancelled');
create type request_status as enum ('open','fulfilled','cancelled','expired');
create type dose_status as enum ('taken','skipped','not_recorded');
create type verify_status as enum ('unverified','pending','verified','rejected');
create type blood_group as enum ('O+','O-','A+','A-','B+','B-','AB+','AB-');

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text, language text not null default 'en' check (language in ('en','ta')),
  abha_id_mock text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table user_roles (
  user_id uuid not null references auth.users(id) on delete cascade, role app_role not null,
  primary key (user_id, role)
);
create table patient_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  ai_record_access boolean not null default false, diet_pref text, allergies text[] default '{}', updated_at timestamptz not null default now()
);
create table emergency_contacts (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  name text not null, phone text not null check (phone ~ '^\+?[0-9]{8,15}$'), created_at timestamptz not null default now()
);
create table medical_documents (          -- FHIR DocumentReference
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  storage_path text not null, doc_type text not null, mime_type text not null, size_bytes int not null check (size_bytes > 0),
  sha256 text, status text not null default 'uploaded', created_at timestamptz not null default now(),
  unique (user_id, sha256)
);
create table extracted_medical_records (  -- reviewed extraction (DiagnosticReport-like)
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  document_id uuid references medical_documents(id) on delete cascade, ocr_provider text, ocr_confidence numeric,
  reviewed boolean not null default false, report_date date, created_at timestamptz not null default now()
);
create table observations (                -- FHIR Observation
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  record_id uuid references extracted_medical_records(id) on delete cascade, name text not null, value text, unit text,
  ref_low numeric, ref_high numeric, observed_on date, source_text text, created_at timestamptz not null default now()
);
create table conditions (                  -- FHIR Condition (clinician-recorded only)
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  name text not null, recorded_by text, recorded_on date, source_document_id uuid references medical_documents(id) on delete set null
);
create table medications (                 -- FHIR MedicationRequest/Statement
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  name text not null, dosage text not null, route text, prescriber text, instructions text,
  source_document_id uuid references medical_documents(id) on delete set null, created_at timestamptz not null default now()
);
create table medication_schedules (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  medication_id uuid not null references medications(id) on delete cascade, times time[] not null,
  start_date date not null, end_date date, reminders_enabled boolean not null default true,
  check (end_date is null or end_date >= start_date)
);
create table medication_adherence (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  schedule_id uuid not null references medication_schedules(id) on delete cascade, scheduled_for timestamptz not null,
  status dose_status not null default 'not_recorded', recorded_at timestamptz, unique (schedule_id, scheduled_for)
);
create table meal_plans (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  title text not null, clinician_approved boolean not null default false, details jsonb not null default '{}'
);
create table wellness_logs (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  log_date date not null, water_glasses int check (water_glasses >= 0), sleep_hours numeric check (sleep_hours between 0 and 24),
  activity_minutes int check (activity_minutes >= 0), notes text, unique (user_id, log_date)
);

create table doctor_specialties ( id serial primary key, name text not null unique, description text );
create table hospitals (
  id uuid primary key default gen_random_uuid(), name text not null, city text not null, locality text,
  lat double precision, lng double precision, maternity boolean not null default false,
  is_demo boolean not null default false, verification verify_status not null default 'unverified'
);
create table doctors (
  id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete set null,
  full_name text not null, specialty_id int references doctor_specialties(id), hospital_id uuid references hospitals(id),
  qualifications text, registration_no text, experience_years int, fee_inr int, languages text[] default '{}',
  online boolean not null default false, home_visit boolean not null default false, service_area text,
  verification verify_status not null default 'unverified', is_demo boolean not null default false, created_at timestamptz not null default now()
);
create table doctor_availability (
  id uuid primary key default gen_random_uuid(), doctor_id uuid not null references doctors(id) on delete cascade,
  starts_at timestamptz not null, ends_at timestamptz not null, check (ends_at > starts_at), unique (doctor_id, starts_at)
);
create table appointments (                -- FHIR Appointment
  id uuid primary key default gen_random_uuid(), patient_id uuid not null references auth.users(id) on delete cascade,
  doctor_id uuid not null references doctors(id), slot_id uuid references doctor_availability(id),
  status appt_status not null default 'requested', reason text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table home_visit_requests (
  id uuid primary key default gen_random_uuid(), patient_id uuid not null references auth.users(id) on delete cascade,
  doctor_id uuid not null references doctors(id), service text not null, preferred_time timestamptz, general_location text,
  contact_pref text, status home_status not null default 'pending', created_at timestamptz not null default now()
);

create table blood_donor_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade, display_name text not null, blood_group blood_group not null,
  city text not null, locality text, available boolean not null default true, last_donation date,
  consent_to_match boolean not null default false, notify_in_app boolean not null default true,
  verification verify_status not null default 'unverified', is_demo boolean not null default false
);
create table blood_requests (
  id uuid primary key default gen_random_uuid(), requester_id uuid not null references auth.users(id) on delete cascade,
  blood_group blood_group not null, units int check (units between 1 and 20), hospital text not null, city text not null, locality text,
  required_by date not null, urgency text not null check (urgency in ('routine','urgent','critical')),
  status request_status not null default 'open', verification verify_status not null default 'unverified', created_at timestamptz not null default now()
);
create unique index blood_requests_open_dedupe on blood_requests (requester_id, blood_group, lower(hospital), lower(city)) where status = 'open';
create table blood_request_matches (
  id uuid primary key default gen_random_uuid(), request_id uuid not null references blood_requests(id) on delete cascade,
  donor_id uuid not null references blood_donor_profiles(user_id) on delete cascade,
  response text check (response in ('accepted','declined')), notified_at timestamptz not null default now(), unique (request_id, donor_id)
);
create table notifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null, title text not null, body text, read boolean not null default false, created_at timestamptz not null default now()
);
create table chat_sessions ( id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade, created_at timestamptz not null default now() );
create table chat_messages (
  id uuid primary key default gen_random_uuid(), session_id uuid not null references chat_sessions(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade, role text not null check (role in ('user','assistant')),
  content text not null, created_at timestamptz not null default now()
);
create table audit_events (
  id bigserial primary key, actor_id uuid, action text not null, entity text not null, entity_id text, at timestamptz not null default now()
); -- never put medical content here
create table consent_records (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  purpose text not null, granted boolean not null, at timestamptz not null default now()
);

create index on observations (user_id, observed_on desc);
create index on appointments (patient_id, status);
create index on blood_donor_profiles (city, blood_group) where consent_to_match and available;
create index on notifications (user_id, read, created_at desc);

-- Role helper (roles are only writable server-side with the service role).
create function has_role(r app_role) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from user_roles where user_id = auth.uid() and role = r) $$;

-- Row Level Security: owner-only tables
do $$
declare t text;
begin
  foreach t in array array['patient_preferences','emergency_contacts','medical_documents','extracted_medical_records','observations','conditions',
    'medications','medication_schedules','medication_adherence','meal_plans','wellness_logs','blood_donor_profiles','notifications','chat_sessions','chat_messages','consent_records']
  loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy "owner all" on %I for all using (user_id = auth.uid()) with check (user_id = auth.uid())', t);
  end loop;
end $$;

alter table profiles enable row level security;
create policy "own profile" on profiles for all using (id = auth.uid()) with check (id = auth.uid());
alter table user_roles enable row level security;
create policy "read own roles" on user_roles for select using (user_id = auth.uid()); -- no insert/update policy: server only

alter table doctor_specialties enable row level security;
create policy "public read" on doctor_specialties for select using (true);
alter table hospitals enable row level security;
create policy "public read" on hospitals for select using (true);
alter table doctors enable row level security;
create policy "public read" on doctors for select using (verification = 'verified' or is_demo);
create policy "doctor edits own" on doctors for update using (user_id = auth.uid()) with check (user_id = auth.uid() and verification = (select d.verification from doctors d where d.id = doctors.id));
alter table doctor_availability enable row level security;
create policy "public read" on doctor_availability for select using (true);
create policy "doctor manages" on doctor_availability for all using (exists (select 1 from doctors d where d.id = doctor_id and d.user_id = auth.uid()));

alter table appointments enable row level security;
create policy "patient or doctor" on appointments for select using (patient_id = auth.uid() or exists (select 1 from doctors d where d.id = doctor_id and d.user_id = auth.uid()));
create policy "patient creates" on appointments for insert with check (patient_id = auth.uid() and status = 'requested');
create policy "participants update" on appointments for update using (patient_id = auth.uid() or exists (select 1 from doctors d where d.id = doctor_id and d.user_id = auth.uid()));
alter table home_visit_requests enable row level security;
create policy "patient or doctor" on home_visit_requests for select using (patient_id = auth.uid() or exists (select 1 from doctors d where d.id = doctor_id and d.user_id = auth.uid()));
create policy "patient creates" on home_visit_requests for insert with check (patient_id = auth.uid() and status = 'pending');
create policy "participants update" on home_visit_requests for update using (patient_id = auth.uid() or exists (select 1 from doctors d where d.id = doctor_id and d.user_id = auth.uid()));

alter table blood_requests enable row level security;
create policy "requester" on blood_requests for all using (requester_id = auth.uid()) with check (requester_id = auth.uid());
alter table blood_request_matches enable row level security;
create policy "donor sees own matches" on blood_request_matches for select using (donor_id = auth.uid());
create policy "donor responds" on blood_request_matches for update using (donor_id = auth.uid()) with check (donor_id = auth.uid());
alter table audit_events enable row level security;  -- no policies: service role only

-- Admins deliberately get NO policy on medical tables.

-- Private storage bucket; objects live under <user_id>/...
insert into storage.buckets (id, name, public) values ('medical-documents', 'medical-documents', false) on conflict do nothing;
create policy "own files read" on storage.objects for select using (bucket_id = 'medical-documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "own files write" on storage.objects for insert with check (bucket_id = 'medical-documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "own files delete" on storage.objects for delete using (bucket_id = 'medical-documents' and (storage.foldername(name))[1] = auth.uid()::text);
